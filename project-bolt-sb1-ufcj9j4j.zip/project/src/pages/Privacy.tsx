import React from 'react';

const Privacy = () => {
  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
      <h1 className="text-4xl font-bold mb-8 bg-gradient-to-r from-accent-blue to-accent-purple bg-clip-text text-transparent">
        Privacy Policy
      </h1>
      
      <div className="prose prose-invert">
        <section className="mb-8">
          <h2 className="text-2xl font-semibold mb-4">1. Information Collection</h2>
          <p className="text-gray-300">
            We collect information that you provide directly to us when using the Ethical Analyzer service, including the scenarios you submit for analysis.
          </p>
        </section>

        <section className="mb-8">
          <h2 className="text-2xl font-semibold mb-4">2. Use of Information</h2>
          <p className="text-gray-300">
            The information we collect is used to provide and improve our service, develop new features, and enhance the user experience.
          </p>
        </section>

        <section className="mb-8">
          <h2 className="text-2xl font-semibold mb-4">3. Data Security</h2>
          <p className="text-gray-300">
            We implement appropriate security measures to protect your information from unauthorized access, alteration, or destruction.
          </p>
        </section>

        <section className="mb-8">
          <h2 className="text-2xl font-semibold mb-4">4. Updates to Policy</h2>
          <p className="text-gray-300">
            We may update this Privacy Policy from time to time. We will notify you of any changes by posting the new Privacy Policy on this page.
          </p>
        </section>
      </div>
    </div>
  );
};

export default Privacy;