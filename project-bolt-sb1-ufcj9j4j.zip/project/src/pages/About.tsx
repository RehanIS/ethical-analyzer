import React from 'react';
import { Brain, Shield, Users, Lightbulb } from 'lucide-react';

const About = () => {
  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
      <div className="text-center mb-16">
        <h1 className="text-4xl font-bold mb-6 bg-gradient-to-r from-accent-blue to-accent-purple bg-clip-text text-transparent">
          About Ethical Analyzer
        </h1>
        <p className="text-lg text-gray-300">
          Empowering better decision-making through AI-powered ethical analysis
        </p>
      </div>

      <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-2">
        <div className="bg-secondary p-6 rounded-lg border border-gray-700">
          <Brain className="w-12 h-12 text-accent-purple mb-4" />
          <h3 className="text-xl font-semibold mb-3">AI-Powered Analysis</h3>
          <p className="text-gray-300">
            Our advanced AI system analyzes complex ethical scenarios using state-of-the-art natural language processing.
          </p>
        </div>

        <div className="bg-secondary p-6 rounded-lg border border-gray-700">
          <Shield className="w-12 h-12 text-accent-blue mb-4" />
          <h3 className="text-xl font-semibold mb-3">Ethical Framework</h3>
          <p className="text-gray-300">
            Built on comprehensive ethical principles and guidelines to ensure thorough and balanced analysis.
          </p>
        </div>

        <div className="bg-secondary p-6 rounded-lg border border-gray-700">
          <Users className="w-12 h-12 text-accent-green mb-4" />
          <h3 className="text-xl font-semibold mb-3">User-Centric Design</h3>
          <p className="text-gray-300">
            Designed with users in mind, providing clear insights and actionable recommendations.
          </p>
        </div>

        <div className="bg-secondary p-6 rounded-lg border border-gray-700">
          <Lightbulb className="w-12 h-12 text-yellow-400 mb-4" />
          <h3 className="text-xl font-semibold mb-3">Continuous Learning</h3>
          <p className="text-gray-300">
            Our system continuously improves through user feedback and evolving ethical standards.
          </p>
        </div>
      </div>
    </div>
  );
};

export default About;