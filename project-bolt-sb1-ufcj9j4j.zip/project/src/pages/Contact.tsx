import React, { useState } from 'react';
import { Mail, MessageSquare, Send } from 'lucide-react';

const Contact = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    message: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle form submission here
    console.log('Form submitted:', formData);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
      <div className="text-center mb-16">
        <h1 className="text-4xl font-bold mb-6 bg-gradient-to-r from-accent-blue to-accent-purple bg-clip-text text-transparent">
          Contact Us
        </h1>
        <p className="text-lg text-gray-300">
          Have questions or feedback? We'd love to hear from you.
        </p>
      </div>

      <div className="bg-secondary p-8 rounded-lg border border-gray-700">
        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label htmlFor="name" className="block text-sm font-medium text-gray-300 mb-2">
              Name
            </label>
            <input
              type="text"
              id="name"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              className="w-full px-4 py-2 bg-primary rounded-lg border border-gray-700 focus:border-accent-blue focus:ring-1 focus:ring-accent-blue outline-none transition-all duration-200 text-white"
              required
            />
          </div>

          <div>
            <label htmlFor="email" className="block text-sm font-medium text-gray-300 mb-2">
              Email
            </label>
            <input
              type="email"
              id="email"
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              className="w-full px-4 py-2 bg-primary rounded-lg border border-gray-700 focus:border-accent-blue focus:ring-1 focus:ring-accent-blue outline-none transition-all duration-200 text-white"
              required
            />
          </div>

          <div>
            <label htmlFor="message" className="block text-sm font-medium text-gray-300 mb-2">
              Message
            </label>
            <textarea
              id="message"
              value={formData.message}
              onChange={(e) => setFormData({ ...formData, message: e.target.value })}
              rows={5}
              className="w-full px-4 py-2 bg-primary rounded-lg border border-gray-700 focus:border-accent-blue focus:ring-1 focus:ring-accent-blue outline-none transition-all duration-200 text-white"
              required
            />
          </div>

          <button
            type="submit"
            className="w-full sm:w-auto px-8 py-4 bg-gradient-to-r from-accent-blue to-accent-purple rounded-lg font-semibold flex items-center justify-center gap-2 transition-all duration-200 hover:opacity-90"
          >
            <Send className="w-5 h-5" />
            Send Message
          </button>
        </form>

        <div className="mt-12 grid gap-6 md:grid-cols-2">
          <div className="flex items-center gap-4">
            <Mail className="w-8 h-8 text-accent-blue" />
            <div>
              <h3 className="font-semibold">Email</h3>
              <p className="text-gray-300">31240911@vupune.ac.in</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <MessageSquare className="w-8 h-8 text-accent-purple" />
            <div>
              <h3 className="font-semibold">Live Chat</h3>
              <p className="text-gray-300">Available 24/7</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Contact;