import React from 'react';

const Terms = () => {
  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
      <h1 className="text-4xl font-bold mb-8 bg-gradient-to-r from-accent-blue to-accent-purple bg-clip-text text-transparent">
        Terms of Service
      </h1>
      
      <div className="prose prose-invert">
        <section className="mb-8">
          <h2 className="text-2xl font-semibold mb-4">1. Acceptance of Terms</h2>
          <p className="text-gray-300">
            By accessing and using the Ethical Analyzer service, you agree to be bound by these Terms of Service and all applicable laws and regulations.
          </p>
        </section>

        <section className="mb-8">
          <h2 className="text-2xl font-semibold mb-4">2. Use of Service</h2>
          <p className="text-gray-300">
            The Ethical Analyzer service is provided for informational purposes only. The analysis and recommendations provided should not be considered as professional or legal advice.
          </p>
        </section>

        <section className="mb-8">
          <h2 className="text-2xl font-semibold mb-4">3. Privacy</h2>
          <p className="text-gray-300">
            Your use of the Ethical Analyzer service is also governed by our Privacy Policy. Please review our Privacy Policy to understand our practices.
          </p>
        </section>

        <section className="mb-8">
          <h2 className="text-2xl font-semibold mb-4">4. Limitations</h2>
          <p className="text-gray-300">
            We strive to provide accurate and helpful analysis, but we cannot guarantee the accuracy or completeness of the results. Use the service at your own discretion.
          </p>
        </section>
      </div>
    </div>
  );
};

export default Terms;