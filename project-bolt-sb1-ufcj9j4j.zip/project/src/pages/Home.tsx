import React, { useState } from 'react';
import { Brain, Send, Loader2, CheckCircle, XCircle, ChevronDown, ChevronUp, ArrowDown } from 'lucide-react';
import ProgressBar from '../components/ProgressBar';

interface Analysis {
  analysis: string;
  risk_score: number;
  recommendations: string[];
  checklist: Record<string, boolean>;
}

const Home = () => {
  const [scenario, setScenario] = useState('');
  const [loading, setLoading] = useState(false);
  const [analysis, setAnalysis] = useState<Analysis | null>(null);
  const [showAnalysis, setShowAnalysis] = useState(true);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const response = await fetch('https://ethical-analyzer.onrender.com/analyze', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ scenario }),
      });

      const data = await response.json();
      // Convert risk_score to a value between 0 and 1
      data.risk_score = data.risk_score / 100;
      setAnalysis(data);
    } catch (error) {
      console.error('Error:', error);
    } finally {
      setLoading(false);
    }
  };

  const scrollToAnalysis = () => {
    const analysisSection = document.getElementById('analysis-section');
    if (analysisSection) {
      analysisSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div>
      {/* Hero Section */}
      <section className="relative z-10 pt-20 pb-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center">
          <Brain className="w-20 h-20 mx-auto mb-8 text-accent-purple animate-float" />
          <h1 className="text-4xl sm:text-6xl font-bold mb-6 bg-gradient-to-r from-accent-blue via-accent-purple to-accent-green bg-clip-text text-transparent animate-gradient">
            Welcome to EthicaAI
          </h1>
          <p className="text-lg sm:text-xl text-gray-300 mb-8">
            Navigating the Future of Ethical AI
          </p>
          <div className="max-w-3xl mx-auto text-gray-300 space-y-6">
            <p>
              In a world where Artificial Intelligence is rapidly shaping our future, making ethically sound decisions has never been more important. EthicaAI helps you navigate these complex ethical dilemmas with confidence. Powered by cutting-edge AI, we offer detailed analyses of your scenarios based on renowned ethical frameworks, ensuring that your AI solutions adhere to the highest standards of ethics and integrity.
            </p>
            <button
              onClick={scrollToAnalysis}
              className="mt-8 px-8 py-4 bg-gradient-to-r from-accent-blue to-accent-purple rounded-lg font-semibold flex items-center gap-2 mx-auto hover:opacity-90 transition-all duration-200"
            >
              Start Analysis
              <ArrowDown className="w-5 h-5" />
            </button>
          </div>
        </div>
      </section>

      {/* What We Do Section */}
      <section className="relative z-10 py-16 px-4 sm:px-6 lg:px-8 bg-secondary bg-opacity-50">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl font-bold mb-6 text-center">What We Do</h2>
          <p className="text-gray-300 mb-8 text-center">
            EthicaAI leverages the power of machine learning and ethical theory to evaluate AI-driven scenarios and provide actionable insights. Whether you're a developer, business leader, or policymaker, our platform helps you assess the ethical implications of your decisions, identify risks, and ensure compliance with core ethical principles.
          </p>
        </div>
      </section>

      {/* Key Features Section */}
      <section className="relative z-10 py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl font-bold mb-8 text-center">Key Features</h2>
          <div className="grid gap-6 md:grid-cols-2">
            <div className="bg-secondary p-6 rounded-lg border border-gray-700">
              <h3 className="text-xl font-semibold mb-3">Comprehensive Ethical Analysis</h3>
              <p className="text-gray-300">
                We analyze AI-based scenarios using frameworks like Utilitarianism, Deontology, and the Engineering Code of Conduct.
              </p>
            </div>
            <div className="bg-secondary p-6 rounded-lg border border-gray-700">
              <h3 className="text-xl font-semibold mb-3">Risk Scoring</h3>
              <p className="text-gray-300">
                Each scenario is assigned a risk score from 0 to 100, helping you gauge potential ethical risks.
              </p>
            </div>
            <div className="bg-secondary p-6 rounded-lg border border-gray-700">
              <h3 className="text-xl font-semibold mb-3">Actionable Recommendations</h3>
              <p className="text-gray-300">
                Get tailored suggestions to improve the ethical integrity of your AI solutions.
              </p>
            </div>
            <div className="bg-secondary p-6 rounded-lg border border-gray-700">
              <h3 className="text-xl font-semibold mb-3">Ethical Checklist</h3>
              <p className="text-gray-300">
                Evaluate your AI system on key ethical aspects like Bias Detection, Transparency, Data Privacy, and Human Oversight.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Why Choose Us Section */}
      <section className="relative z-10 py-16 px-4 sm:px-6 lg:px-8 bg-secondary bg-opacity-50">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl font-bold mb-8 text-center">Why Choose EthicaAI?</h2>
          <div className="grid gap-6 md:grid-cols-3">
            <div className="text-center">
              <h3 className="text-xl font-semibold mb-3">Trusted Ethical Frameworks</h3>
              <p className="text-gray-300">
                We base our analyses on time-tested ethical philosophies and engineering codes.
              </p>
            </div>
            <div className="text-center">
              <h3 className="text-xl font-semibold mb-3">AI-Powered Accuracy</h3>
              <p className="text-gray-300">
                EthicaAI uses advanced AI to process and provide reliable, consistent assessments.
              </p>
            </div>
            <div className="text-center">
              <h3 className="text-xl font-semibold mb-3">Real-Time Analysis</h3>
              <p className="text-gray-300">
                Quickly analyze multiple scenarios and make informed decisions faster.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Analysis Form Section */}
      <section id="analysis-section" className="relative z-10 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <h2 className="text-3xl font-bold mb-8 text-center">Start Ethical Decision-Making Today</h2>
        <p className="text-center text-gray-300 mb-8">
          AI is shaping the future, and with EthicaAI, you can ensure that the future remains ethically sound. Start by analyzing your first scenario now and be part of the movement toward more responsible, ethical AI innovation.
        </p>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="relative">
            <textarea
              value={scenario}
              onChange={(e) => setScenario(e.target.value)}
              placeholder="Describe your ethical scenario here..."
              className="w-full h-40 px-4 py-3 bg-secondary rounded-lg border border-gray-700 focus:border-accent-blue focus:ring-1 focus:ring-accent-blue outline-none transition-all duration-200 text-white placeholder-gray-400"
            />
          </div>
          <button
            type="submit"
            disabled={loading || !scenario.trim()}
            className={`w-full sm:w-auto px-8 py-4 bg-gradient-to-r from-accent-blue to-accent-purple rounded-lg font-semibold flex items-center justify-center gap-2 transition-all duration-200 hover:opacity-90 disabled:opacity-50 disabled:cursor-not-allowed ${
              loading ? 'cursor-wait' : ''
            }`}
          >
            {loading ? (
              <Loader2 className="w-5 h-5 animate-spin" />
            ) : (
              <>
                <Send className="w-5 h-5" />
                Start Analyzing
              </>
            )}
          </button>
        </form>
      </section>

      {/* Analysis Results */}
      {analysis && (
        <section className="relative z-10 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 mb-16">
          <div className="bg-secondary rounded-lg p-6 space-y-6 border border-gray-700">
            <div
              className="flex justify-between items-center cursor-pointer"
              onClick={() => setShowAnalysis(!showAnalysis)}
            >
              <h2 className="text-2xl font-semibold">Analysis Results</h2>
              {showAnalysis ? (
                <ChevronUp className="w-6 h-6 text-accent-blue" />
              ) : (
                <ChevronDown className="w-6 h-6 text-accent-blue" />
              )}
            </div>

            {showAnalysis && (
              <div className="space-y-6">
                <div>
                  <h3 className="text-xl font-semibold mb-4">Risk Score</h3>
                  <ProgressBar value={analysis.risk_score} />
                </div>

                <div>
                  <h3 className="text-xl font-semibold mb-4">Detailed Analysis</h3>
                  <p className="text-gray-300">{analysis.analysis}</p>
                </div>

                <div>
                  <h3 className="text-xl font-semibold mb-4">Recommendations</h3>
                  <ul className="space-y-3">
                    {analysis.recommendations.map((rec, index) => (
                      <li
                        key={index}
                        className="flex items-start gap-3 p-4 bg-primary rounded-lg border border-gray-700"
                      >
                        <CheckCircle className="w-6 h-6 text-accent-green flex-shrink-0" />
                        <span>{rec}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div>
                  <h3 className="text-xl font-semibold mb-4">Ethical Factors Checklist</h3>
                  <div className="grid gap-4 sm:grid-cols-2">
                    {Object.entries(analysis.checklist).map(([factor, value]) => (
                      <div
                        key={factor}
                        className="flex items-center gap-3 p-4 bg-primary rounded-lg border border-gray-700"
                      >
                        {value ? (
                          <CheckCircle className="w-6 h-6 text-accent-green flex-shrink-0" />
                        ) : (
                          <XCircle className="w-6 h-6 text-red-500 flex-shrink-0" />
                        )}
                        <span className="capitalize">{factor.replace(/_/g, ' ')}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>
        </section>
      )}
    </div>
  );
};

export default Home;