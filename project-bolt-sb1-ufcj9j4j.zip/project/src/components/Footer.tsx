import React from 'react';
import { Link } from 'react-router-dom';

const Footer = () => {
  return (
    <footer className="relative z-10 bg-secondary py-8 mt-16">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
          <div className="text-sm text-gray-400">
            © 2025 EthicaAI. All rights reserved.
          </div>
          <div className="flex gap-6">
            <Link to="/contact" className="text-sm text-gray-400 hover:text-accent-blue transition-colors">
              Contact
            </Link>
            <Link to="/terms" className="text-sm text-gray-400 hover:text-accent-blue transition-colors">
              Terms of Service
            </Link>
            <Link to="/privacy" className="text-sm text-gray-400 hover:text-accent-blue transition-colors">
              Privacy Policy
            </Link>
          </div>
        </div>
        <div className="text-sm text-gray-400 text-center mt-4">
          Made by Rehan ~ Powered by Cohere enterprise AI and Render ~ Hosted on Netlify
        </div>
      </div>
    </footer>
  );
};

export default Footer;