import React from 'react';

interface ProgressBarProps {
  value: number;
}

const ProgressBar: React.FC<ProgressBarProps> = ({ value }) => {
  // Ensure value is between 0 and 1
  const normalizedValue = Math.min(Math.max(value, 0), 1);
  const percentage = normalizedValue * 100;
  
  const getColor = (value: number) => {
    if (value < 0.3) return 'from-green-500 to-accent-green';
    if (value < 0.7) return 'from-yellow-500 to-yellow-400';
    return 'from-red-500 to-red-400';
  };

  return (
    <div className="relative pt-1">
      <div className="flex items-center justify-between mb-2">
        <span className="text-xs font-semibold inline-block py-1 px-2 uppercase rounded-full bg-opacity-20 bg-accent-blue text-accent-blue">
          Risk Level
        </span>
        <span className="text-xs font-semibold inline-block text-accent-blue">
          {percentage.toFixed(0)}%
        </span>
      </div>
      <div className="flex h-2 mb-4 overflow-hidden bg-gray-700 rounded">
        <div
          style={{ width: `${percentage}%` }}
          className={`flex flex-col justify-center rounded bg-gradient-to-r ${getColor(normalizedValue)} transition-all duration-500 ease-in-out`}
        />
      </div>
    </div>
  );
};

export default ProgressBar;